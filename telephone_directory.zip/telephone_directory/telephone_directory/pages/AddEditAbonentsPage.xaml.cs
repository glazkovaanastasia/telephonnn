﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using telephone_directory.classes;

namespace telephone_directory.pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditAbonentsPage.xaml
    /// </summary>
    public partial class AddEditAbonentsPage : Page
    {
        private object selectedAbonents;
        private object _currentAbonents;

        public AddEditAbonentsPage()
        {
            InitializeComponent();
            if (selectedAbonents != null)
                _currentAbonents = selectedAbonents;
            //создаем контекст
            DataContext = _currentAbonents;
        }

        public AddEditAbonentsPage(object p)
        {
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder(); //объект для сообщения об ошибке

            //если пользователь новый
            if (_currentAbonents.idAbonent == 0)
                InTouchEntities1.GetContext().Abonents.Add(_currentAbonents); //добавить в контекст
            else
            {
            }
            try
            {
                InTouchEntities1.GetContext().SaveChanges(); // сохраняет все изменения
                MessageBox.Show("Новый абонент добавлен");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString()); //сообщение об ошибке
            }
        }
    }
}
