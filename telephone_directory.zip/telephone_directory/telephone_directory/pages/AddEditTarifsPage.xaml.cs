﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using telephone_directory.classes;

namespace telephone_directory.pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditTarifsPage.xaml
    /// </summary>
    public partial class AddEditTarifsPage : Page
    {
        private object selectedTarifs;
        private object _currentTarifs;

        public AddEditTarifsPage(object p)
        {
            InitializeComponent();
            if (selectedTarifs != null)
                _currentTarifs = selectedTarifs;
            //создаем контекст
            DataContext = _currentTarifs;
        }
        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder(); //объект для сообщения об ошибке


            //если пользователь новый
            if (_currentTarifs.idTarif != 0)
            {
            }
            else
                InTouchEntities1.GetContext().Tarif.Add((Tarif)_currentTarifs); //добавить в контекст
            try
            {
                InTouchEntities1.GetContext().SaveChanges(); // сохраняет все изменения
                MessageBox.Show("Новый продукт добавлен");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString()); //сообщение об ошибке
            }
        }
    }
}
