﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using telephone_directory.classes;

namespace telephone_directory.pages
{
    /// <summary>
    /// Логика взаимодействия для PageAbonent.xaml
    /// </summary>
    public partial class PageAbonent : Page
    {
        public PageAbonent()
        {
            InitializeComponent();
            DGridAbonents.ItemsSource = InTouchEntities1.GetContext().Abonent.ToList();
        }

        private void TxbSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            DGridAbonents.ItemsSource = InTouchEntities1.GetContext().Abonent.Where(x => x.FIO.ToLower().Contains(TxbSearch.Text.ToLower())).ToList();

        }

        private void BtnResetAll_Click(object sender, RoutedEventArgs e)
        {
            DGridAbonents.ItemsSource = InTouchEntities1.GetContext().Abonent.ToList();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddEditAbonentsPage(null));
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            var abonentForRemoving = DGridAbonents.SelectedItems.Cast<Abonent>().ToList();

            if (MessageBox.Show($"Вы действительно хотите удалить {abonentForRemoving.Count()} данный абонента?",
                "Внимание!", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    InTouchEntities1.GetContext().Abonents.RemoveRange(abonentForRemoving);
                    InTouchEntities1.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");

                    DGridAbonents.ItemsSource = InTouchEntities1.GetContext().Abonents.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }
        private void BtnNum_Click(object sender, RoutedEventArgs e)
        {
            int countRow = DGridAbonents.Items.Count;
            TxtNum.Text = countRow.ToString();
        }
    }
}
