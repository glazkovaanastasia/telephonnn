﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using telephone_directory.classes;

namespace telephone_directory.pages
{
    /// <summary>
    /// Логика взаимодействия для PageTarif.xaml
    /// </summary>
    public partial class PageTarif : Page
    {
        public PageTarif()
        {
            InitializeComponent();
            DGridTarifs.ItemsSource = InTouchEntities1.GetContext().Tarif.ToList();

            CmbFiltrTarif.ItemsSource = InTouchEntities1.GetContext().Tarif.ToList();
            CmbFiltrTarif.SelectedValuePath = "Id_Tarifs";
        }

        private void CmbFiltrTarif_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int id = CmbFiltrTarif.SelectedIndex + 1;
            DGridTarifs.ItemsSource = InTouchEntities1.GetContext().Tarif.Where(x => x.idTarif == id).ToList();
        }

        private void BtnResetAll_Click(object sender, RoutedEventArgs e)
        {
            DGridTarifs.ItemsSource = InTouchEntities1.GetContext().Tarif.ToList();
        }

        private void BtnNum_Click(object sender, RoutedEventArgs e)
        {
            int countRow = DGridTarifs.Items.Count;
            TxtNum.Text = countRow.ToString();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new AddEditTarifsPage(null));
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            var tarifForRemoving = DGridTarifs.SelectedItems.Cast<Tarif>().ToList();

            if (MessageBox.Show($"Вы действительно хотите удалить {tarifForRemoving.Count()} данный тариф?",
                "Внимание!", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    InTouchEntities1.GetContext().Tarif.RemoveRange(tarifForRemoving);
                    InTouchEntities1.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены!");

                    DGridTarifs.ItemsSource = InTouchEntities1.GetContext().Tarif.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

    }
}
}
